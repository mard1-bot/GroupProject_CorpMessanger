--
-- PostgreSQL database dump
--

\restrict W4HHexRgKk2dS0jVYIukwWvZvPLWndw1uuT3x7ChtIBpjPdVVJApSHkRf4O288e

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: cleanup_old_login_attempts(); Type: FUNCTION; Schema: public; Owner: corpmessenger
--

CREATE FUNCTION public.cleanup_old_login_attempts() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM login_attempts WHERE created_at < NOW() - INTERVAL '30 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_login_attempts() OWNER TO corpmessenger;

--
-- Name: update_unread_count(); Type: FUNCTION; Schema: public; Owner: corpmessenger
--

CREATE FUNCTION public.update_unread_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    INSERT INTO unread_counts (user_id, chat_id, count, updated_at)
    SELECT cm.user_id, NEW.chat_id, 1, NOW()
    FROM chat_members cm
    WHERE cm.chat_id = NEW.chat_id AND cm.user_id != NEW.sender_id
    ON CONFLICT (user_id, chat_id)
    DO UPDATE SET count = unread_counts.count + 1, updated_at = NOW();
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_unread_count() OWNER TO corpmessenger;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    action character varying(100) NOT NULL,
    resource character varying(50) NOT NULL,
    resource_id character varying(255),
    details text,
    ip_address character varying(45),
    user_agent text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO corpmessenger;

--
-- Name: blocked_users; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.blocked_users (
    blocker_id uuid NOT NULL,
    blocked_id uuid NOT NULL,
    blocked_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.blocked_users OWNER TO corpmessenger;

--
-- Name: bookmarks; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.bookmarks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    message_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.bookmarks OWNER TO corpmessenger;

--
-- Name: chat_members; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.chat_members (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    chat_id uuid,
    user_id uuid,
    role character varying(20) DEFAULT 'member'::character varying,
    joined_at timestamp with time zone DEFAULT now(),
    muted boolean DEFAULT false NOT NULL,
    pinned boolean DEFAULT false,
    archived boolean DEFAULT false,
    deleted_at timestamp with time zone
);


ALTER TABLE public.chat_members OWNER TO corpmessenger;

--
-- Name: chats; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.chats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying(20) NOT NULL,
    title character varying(255),
    creator_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.chats OWNER TO corpmessenger;

--
-- Name: deleted_messages; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.deleted_messages (
    user_id uuid NOT NULL,
    message_id uuid NOT NULL,
    deleted_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.deleted_messages OWNER TO corpmessenger;

--
-- Name: device_tokens; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.device_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    token character varying(255) NOT NULL,
    platform character varying(20) NOT NULL,
    device_name character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    last_used_at timestamp with time zone DEFAULT now(),
    CONSTRAINT device_tokens_platform_check CHECK (((platform)::text = ANY ((ARRAY['ios'::character varying, 'android'::character varying, 'web'::character varying])::text[])))
);


ALTER TABLE public.device_tokens OWNER TO corpmessenger;

--
-- Name: encryption_keys; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.encryption_keys (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    public_key text NOT NULL,
    private_key text,
    key_version integer DEFAULT 1,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.encryption_keys OWNER TO corpmessenger;

--
-- Name: files; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.files (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid,
    name character varying(255) NOT NULL,
    size bigint NOT NULL,
    mime_type character varying(100) NOT NULL,
    url text NOT NULL,
    uploaded_at timestamp with time zone DEFAULT now(),
    thumbnail_url text
);


ALTER TABLE public.files OWNER TO corpmessenger;

--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.login_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    ip_address character varying(45),
    user_id uuid,
    success boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.login_attempts OWNER TO corpmessenger;

--
-- Name: mentions; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.mentions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid,
    mentioned_user_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.mentions OWNER TO corpmessenger;

--
-- Name: message_reads; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.message_reads (
    message_id uuid NOT NULL,
    user_id uuid NOT NULL,
    read_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.message_reads OWNER TO corpmessenger;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    chat_id uuid,
    sender_id uuid,
    type character varying(20) DEFAULT 'text'::character varying,
    content text NOT NULL,
    file_url text,
    reply_to uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    encrypted_content text,
    encryption_key_id uuid,
    encrypted_keys jsonb,
    latitude double precision,
    longitude double precision,
    location_address text,
    duration double precision,
    scheduled_at timestamp without time zone,
    thread_id uuid,
    forwarded_from uuid,
    forwarded_sender_name character varying(255),
    synced_to_xmpp boolean DEFAULT false,
    xmpp_message_id character varying(255)
);


ALTER TABLE public.messages OWNER TO corpmessenger;

--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.notification_settings (
    user_id uuid NOT NULL,
    push_enabled boolean DEFAULT true,
    email_enabled boolean DEFAULT true,
    email character varying(255),
    quiet_hours_start time without time zone,
    quiet_hours_end time without time zone,
    quiet_hours_enabled boolean DEFAULT false,
    updated_at timestamp with time zone DEFAULT now(),
    protocol_preference character varying(20) DEFAULT 'websocket'::character varying,
    CONSTRAINT notification_settings_protocol_preference_check CHECK (((protocol_preference)::text = ANY ((ARRAY['websocket'::character varying, 'xmpp'::character varying])::text[])))
);


ALTER TABLE public.notification_settings OWNER TO corpmessenger;

--
-- Name: pinned_messages; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.pinned_messages (
    chat_id uuid NOT NULL,
    message_id uuid NOT NULL,
    user_id uuid,
    pinned_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.pinned_messages OWNER TO corpmessenger;

--
-- Name: reactions; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.reactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid,
    user_id uuid,
    emoji character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.reactions OWNER TO corpmessenger;

--
-- Name: scheduler_failures; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.scheduler_failures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid NOT NULL,
    chat_id uuid NOT NULL,
    error_message text NOT NULL,
    error_details jsonb,
    attempts integer DEFAULT 1,
    max_attempts integer DEFAULT 5,
    next_retry_at timestamp with time zone DEFAULT (now() + '00:01:00'::interval),
    last_attempt_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


ALTER TABLE public.scheduler_failures OWNER TO corpmessenger;

--
-- Name: unread_counts; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.unread_counts (
    user_id uuid NOT NULL,
    chat_id uuid NOT NULL,
    count integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.unread_counts OWNER TO corpmessenger;

--
-- Name: users; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    status character varying(20) DEFAULT 'active'::character varying,
    role character varying(20) DEFAULT 'user'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_online timestamp with time zone,
    custom_status text,
    phone character varying(20),
    middle_name character varying(100),
    avatar character varying(255)
);


ALTER TABLE public.users OWNER TO corpmessenger;

--
-- Name: web_push_subscriptions; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.web_push_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    endpoint text NOT NULL,
    key text NOT NULL,
    auth text NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.web_push_subscriptions OWNER TO corpmessenger;

--
-- Name: xmpp_reconciliation; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.xmpp_reconciliation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    chat_id uuid NOT NULL,
    reason text NOT NULL,
    details jsonb,
    created_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 5,
    last_attempt_at timestamp with time zone
);


ALTER TABLE public.xmpp_reconciliation OWNER TO corpmessenger;

--
-- Name: xmpp_sync_dead_letter; Type: TABLE; Schema: public; Owner: corpmessenger
--

CREATE TABLE public.xmpp_sync_dead_letter (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    message_id uuid NOT NULL,
    chat_id uuid NOT NULL,
    error_message text NOT NULL,
    error_details jsonb,
    attempts integer DEFAULT 1,
    max_attempts integer DEFAULT 5,
    last_attempt_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


ALTER TABLE public.xmpp_sync_dead_letter OWNER TO corpmessenger;

--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.audit_logs (id, user_id, action, resource, resource_id, details, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: blocked_users; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.blocked_users (blocker_id, blocked_id, blocked_at) FROM stdin;
\.


--
-- Data for Name: bookmarks; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.bookmarks (id, user_id, message_id, created_at) FROM stdin;
\.


--
-- Data for Name: chat_members; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.chat_members (id, chat_id, user_id, role, joined_at, muted, pinned, archived, deleted_at) FROM stdin;
\.


--
-- Data for Name: chats; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.chats (id, type, title, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deleted_messages; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.deleted_messages (user_id, message_id, deleted_at) FROM stdin;
\.


--
-- Data for Name: device_tokens; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.device_tokens (id, user_id, token, platform, device_name, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: encryption_keys; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.encryption_keys (id, user_id, public_key, private_key, key_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.files (id, message_id, name, size, mime_type, url, uploaded_at, thumbnail_url) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.login_attempts (id, email, ip_address, user_id, success, created_at) FROM stdin;
\.


--
-- Data for Name: mentions; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.mentions (id, message_id, mentioned_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: message_reads; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.message_reads (message_id, user_id, read_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.messages (id, chat_id, sender_id, type, content, file_url, reply_to, created_at, updated_at, encrypted_content, encryption_key_id, encrypted_keys, latitude, longitude, location_address, duration, scheduled_at, thread_id, forwarded_from, forwarded_sender_name, synced_to_xmpp, xmpp_message_id) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.notification_settings (user_id, push_enabled, email_enabled, email, quiet_hours_start, quiet_hours_end, quiet_hours_enabled, updated_at, protocol_preference) FROM stdin;
\.


--
-- Data for Name: pinned_messages; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.pinned_messages (chat_id, message_id, user_id, pinned_at) FROM stdin;
\.


--
-- Data for Name: reactions; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.reactions (id, message_id, user_id, emoji, created_at) FROM stdin;
\.


--
-- Data for Name: scheduler_failures; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.scheduler_failures (id, message_id, chat_id, error_message, error_details, attempts, max_attempts, next_retry_at, last_attempt_at, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: unread_counts; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.unread_counts (user_id, chat_id, count, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.users (id, email, password_hash, first_name, last_name, status, role, created_at, updated_at, last_online, custom_status, phone, middle_name, avatar) FROM stdin;
\.


--
-- Data for Name: web_push_subscriptions; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.web_push_subscriptions (id, user_id, endpoint, key, auth, created_at) FROM stdin;
\.


--
-- Data for Name: xmpp_reconciliation; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.xmpp_reconciliation (id, chat_id, reason, details, created_at, resolved_at, attempts, max_attempts, last_attempt_at) FROM stdin;
\.


--
-- Data for Name: xmpp_sync_dead_letter; Type: TABLE DATA; Schema: public; Owner: corpmessenger
--

COPY public.xmpp_sync_dead_letter (id, message_id, chat_id, error_message, error_details, attempts, max_attempts, last_attempt_at, created_at, resolved_at) FROM stdin;
\.


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: blocked_users blocked_users_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_pkey PRIMARY KEY (blocker_id, blocked_id);


--
-- Name: bookmarks bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_pkey PRIMARY KEY (id);


--
-- Name: bookmarks bookmarks_user_id_message_id_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_user_id_message_id_key UNIQUE (user_id, message_id);


--
-- Name: chat_members chat_members_chat_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_chat_id_user_id_key UNIQUE (chat_id, user_id);


--
-- Name: chat_members chat_members_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_pkey PRIMARY KEY (id);


--
-- Name: chats chats_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_pkey PRIMARY KEY (id);


--
-- Name: deleted_messages deleted_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.deleted_messages
    ADD CONSTRAINT deleted_messages_pkey PRIMARY KEY (user_id, message_id);


--
-- Name: device_tokens device_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT device_tokens_pkey PRIMARY KEY (id);


--
-- Name: device_tokens device_tokens_user_id_token_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT device_tokens_user_id_token_key UNIQUE (user_id, token);


--
-- Name: encryption_keys encryption_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.encryption_keys
    ADD CONSTRAINT encryption_keys_pkey PRIMARY KEY (id);


--
-- Name: encryption_keys encryption_keys_user_id_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.encryption_keys
    ADD CONSTRAINT encryption_keys_user_id_key UNIQUE (user_id);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: mentions mentions_message_id_mentioned_user_id_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_message_id_mentioned_user_id_key UNIQUE (message_id, mentioned_user_id);


--
-- Name: mentions mentions_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_pkey PRIMARY KEY (id);


--
-- Name: message_reads message_reads_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_pkey PRIMARY KEY (message_id, user_id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (user_id);


--
-- Name: pinned_messages pinned_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.pinned_messages
    ADD CONSTRAINT pinned_messages_pkey PRIMARY KEY (chat_id, message_id);


--
-- Name: reactions reactions_message_id_user_id_emoji_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_message_id_user_id_emoji_key UNIQUE (message_id, user_id, emoji);


--
-- Name: reactions reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_pkey PRIMARY KEY (id);


--
-- Name: scheduler_failures scheduler_failures_message_id_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.scheduler_failures
    ADD CONSTRAINT scheduler_failures_message_id_key UNIQUE (message_id);


--
-- Name: scheduler_failures scheduler_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.scheduler_failures
    ADD CONSTRAINT scheduler_failures_pkey PRIMARY KEY (id);


--
-- Name: unread_counts unread_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.unread_counts
    ADD CONSTRAINT unread_counts_pkey PRIMARY KEY (user_id, chat_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: web_push_subscriptions web_push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.web_push_subscriptions
    ADD CONSTRAINT web_push_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: web_push_subscriptions web_push_subscriptions_user_id_endpoint_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.web_push_subscriptions
    ADD CONSTRAINT web_push_subscriptions_user_id_endpoint_key UNIQUE (user_id, endpoint);


--
-- Name: xmpp_reconciliation xmpp_reconciliation_chat_id_reason_resolved_at_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.xmpp_reconciliation
    ADD CONSTRAINT xmpp_reconciliation_chat_id_reason_resolved_at_key UNIQUE (chat_id, reason, resolved_at);


--
-- Name: xmpp_reconciliation xmpp_reconciliation_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.xmpp_reconciliation
    ADD CONSTRAINT xmpp_reconciliation_pkey PRIMARY KEY (id);


--
-- Name: xmpp_sync_dead_letter xmpp_sync_dead_letter_message_id_key; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.xmpp_sync_dead_letter
    ADD CONSTRAINT xmpp_sync_dead_letter_message_id_key UNIQUE (message_id);


--
-- Name: xmpp_sync_dead_letter xmpp_sync_dead_letter_pkey; Type: CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.xmpp_sync_dead_letter
    ADD CONSTRAINT xmpp_sync_dead_letter_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_logs_action; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: idx_audit_logs_created_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_audit_logs_created_at ON public.audit_logs USING btree (created_at DESC);


--
-- Name: idx_audit_logs_resource; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_audit_logs_resource ON public.audit_logs USING btree (resource);


--
-- Name: idx_audit_logs_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: idx_blocked_users_blocker_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_blocked_users_blocker_id ON public.blocked_users USING btree (blocker_id);


--
-- Name: idx_bookmarks_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_bookmarks_user_id ON public.bookmarks USING btree (user_id);


--
-- Name: idx_chat_members_archived; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_chat_members_archived ON public.chat_members USING btree (archived);


--
-- Name: idx_chat_members_chat_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_chat_members_chat_id ON public.chat_members USING btree (chat_id);


--
-- Name: idx_chat_members_deleted_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_chat_members_deleted_at ON public.chat_members USING btree (deleted_at);


--
-- Name: idx_chat_members_muted; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_chat_members_muted ON public.chat_members USING btree (user_id, muted) WHERE (muted = true);


--
-- Name: idx_chat_members_pinned; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_chat_members_pinned ON public.chat_members USING btree (user_id, pinned) WHERE (pinned = true);


--
-- Name: idx_chat_members_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_chat_members_user_id ON public.chat_members USING btree (user_id);


--
-- Name: idx_deleted_messages_message_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_deleted_messages_message_id ON public.deleted_messages USING btree (message_id);


--
-- Name: idx_deleted_messages_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_deleted_messages_user_id ON public.deleted_messages USING btree (user_id);


--
-- Name: idx_device_tokens_token; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_device_tokens_token ON public.device_tokens USING btree (token);


--
-- Name: idx_device_tokens_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_device_tokens_user_id ON public.device_tokens USING btree (user_id);


--
-- Name: idx_encryption_keys_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_encryption_keys_user_id ON public.encryption_keys USING btree (user_id);


--
-- Name: idx_files_message_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_files_message_id ON public.files USING btree (message_id);


--
-- Name: idx_files_thumbnail_url; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_files_thumbnail_url ON public.files USING btree (thumbnail_url);


--
-- Name: idx_login_attempts_created_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_login_attempts_created_at ON public.login_attempts USING btree (created_at);


--
-- Name: idx_login_attempts_email; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_login_attempts_email ON public.login_attempts USING btree (email);


--
-- Name: idx_mentions_message_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_mentions_message_id ON public.mentions USING btree (message_id);


--
-- Name: idx_mentions_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_mentions_user_id ON public.mentions USING btree (mentioned_user_id);


--
-- Name: idx_message_reads_message_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_message_reads_message_id ON public.message_reads USING btree (message_id);


--
-- Name: idx_message_reads_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_message_reads_user_id ON public.message_reads USING btree (user_id);


--
-- Name: idx_messages_chat_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_chat_id ON public.messages USING btree (chat_id);


--
-- Name: idx_messages_created_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_created_at ON public.messages USING btree (created_at);


--
-- Name: idx_messages_encryption_key_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_encryption_key_id ON public.messages USING btree (encryption_key_id);


--
-- Name: idx_messages_forwarded_from; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_forwarded_from ON public.messages USING btree (forwarded_from) WHERE (forwarded_from IS NOT NULL);


--
-- Name: idx_messages_location; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_location ON public.messages USING btree (latitude, longitude) WHERE (latitude IS NOT NULL);


--
-- Name: idx_messages_scheduled_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_scheduled_at ON public.messages USING btree (scheduled_at);


--
-- Name: idx_messages_synced_to_xmpp; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_synced_to_xmpp ON public.messages USING btree (synced_to_xmpp) WHERE (synced_to_xmpp = false);


--
-- Name: idx_messages_thread_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_thread_id ON public.messages USING btree (thread_id);


--
-- Name: idx_messages_xmpp_message_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_messages_xmpp_message_id ON public.messages USING btree (xmpp_message_id) WHERE (xmpp_message_id IS NOT NULL);


--
-- Name: idx_pinned_messages_chat_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_pinned_messages_chat_id ON public.pinned_messages USING btree (chat_id);


--
-- Name: idx_pinned_messages_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_pinned_messages_user_id ON public.pinned_messages USING btree (user_id);


--
-- Name: idx_reactions_message_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_reactions_message_id ON public.reactions USING btree (message_id);


--
-- Name: idx_reactions_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_reactions_user_id ON public.reactions USING btree (user_id);


--
-- Name: idx_scheduler_failures_chat_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_scheduler_failures_chat_id ON public.scheduler_failures USING btree (chat_id);


--
-- Name: idx_scheduler_failures_message_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_scheduler_failures_message_id ON public.scheduler_failures USING btree (message_id);


--
-- Name: idx_scheduler_failures_next_retry_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_scheduler_failures_next_retry_at ON public.scheduler_failures USING btree (next_retry_at) WHERE (resolved_at IS NULL);


--
-- Name: idx_scheduler_failures_resolved_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_scheduler_failures_resolved_at ON public.scheduler_failures USING btree (resolved_at) WHERE (resolved_at IS NULL);


--
-- Name: idx_unread_counts_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_unread_counts_user_id ON public.unread_counts USING btree (user_id);


--
-- Name: idx_users_status; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_users_status ON public.users USING btree (status);


--
-- Name: idx_web_push_subscriptions_user_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_web_push_subscriptions_user_id ON public.web_push_subscriptions USING btree (user_id);


--
-- Name: idx_xmpp_reconciliation_chat_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_xmpp_reconciliation_chat_id ON public.xmpp_reconciliation USING btree (chat_id);


--
-- Name: idx_xmpp_reconciliation_created_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_xmpp_reconciliation_created_at ON public.xmpp_reconciliation USING btree (created_at);


--
-- Name: idx_xmpp_reconciliation_resolved_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_xmpp_reconciliation_resolved_at ON public.xmpp_reconciliation USING btree (resolved_at) WHERE (resolved_at IS NULL);


--
-- Name: idx_xmpp_sync_dead_letter_chat_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_xmpp_sync_dead_letter_chat_id ON public.xmpp_sync_dead_letter USING btree (chat_id);


--
-- Name: idx_xmpp_sync_dead_letter_created_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_xmpp_sync_dead_letter_created_at ON public.xmpp_sync_dead_letter USING btree (created_at);


--
-- Name: idx_xmpp_sync_dead_letter_message_id; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_xmpp_sync_dead_letter_message_id ON public.xmpp_sync_dead_letter USING btree (message_id);


--
-- Name: idx_xmpp_sync_dead_letter_resolved_at; Type: INDEX; Schema: public; Owner: corpmessenger
--

CREATE INDEX idx_xmpp_sync_dead_letter_resolved_at ON public.xmpp_sync_dead_letter USING btree (resolved_at) WHERE (resolved_at IS NULL);


--
-- Name: messages message_unread_count; Type: TRIGGER; Schema: public; Owner: corpmessenger
--

CREATE TRIGGER message_unread_count AFTER INSERT ON public.messages FOR EACH ROW EXECUTE FUNCTION public.update_unread_count();


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: blocked_users blocked_users_blocked_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_blocked_id_fkey FOREIGN KEY (blocked_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: blocked_users blocked_users_blocker_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.blocked_users
    ADD CONSTRAINT blocked_users_blocker_id_fkey FOREIGN KEY (blocker_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: bookmarks bookmarks_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: bookmarks bookmarks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.bookmarks
    ADD CONSTRAINT bookmarks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_members chat_members_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: chat_members chat_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.chat_members
    ADD CONSTRAINT chat_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chats chats_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.chats
    ADD CONSTRAINT chats_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: deleted_messages deleted_messages_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.deleted_messages
    ADD CONSTRAINT deleted_messages_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: deleted_messages deleted_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.deleted_messages
    ADD CONSTRAINT deleted_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: device_tokens device_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.device_tokens
    ADD CONSTRAINT device_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: encryption_keys encryption_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.encryption_keys
    ADD CONSTRAINT encryption_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: files files_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: mentions mentions_mentioned_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_mentioned_user_id_fkey FOREIGN KEY (mentioned_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mentions mentions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.mentions
    ADD CONSTRAINT mentions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_reads message_reads_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_reads message_reads_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.message_reads
    ADD CONSTRAINT message_reads_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: messages messages_reply_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_reply_to_fkey FOREIGN KEY (reply_to) REFERENCES public.messages(id) ON DELETE SET NULL;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notification_settings notification_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: pinned_messages pinned_messages_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.pinned_messages
    ADD CONSTRAINT pinned_messages_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: pinned_messages pinned_messages_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.pinned_messages
    ADD CONSTRAINT pinned_messages_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: pinned_messages pinned_messages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.pinned_messages
    ADD CONSTRAINT pinned_messages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: reactions reactions_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: reactions reactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.reactions
    ADD CONSTRAINT reactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: scheduler_failures scheduler_failures_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.scheduler_failures
    ADD CONSTRAINT scheduler_failures_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: scheduler_failures scheduler_failures_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.scheduler_failures
    ADD CONSTRAINT scheduler_failures_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: unread_counts unread_counts_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.unread_counts
    ADD CONSTRAINT unread_counts_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: unread_counts unread_counts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.unread_counts
    ADD CONSTRAINT unread_counts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: web_push_subscriptions web_push_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.web_push_subscriptions
    ADD CONSTRAINT web_push_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: xmpp_reconciliation xmpp_reconciliation_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.xmpp_reconciliation
    ADD CONSTRAINT xmpp_reconciliation_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: xmpp_sync_dead_letter xmpp_sync_dead_letter_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.xmpp_sync_dead_letter
    ADD CONSTRAINT xmpp_sync_dead_letter_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chats(id) ON DELETE CASCADE;


--
-- Name: xmpp_sync_dead_letter xmpp_sync_dead_letter_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: corpmessenger
--

ALTER TABLE ONLY public.xmpp_sync_dead_letter
    ADD CONSTRAINT xmpp_sync_dead_letter_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict W4HHexRgKk2dS0jVYIukwWvZvPLWndw1uuT3x7ChtIBpjPdVVJApSHkRf4O288e

